step1
update all files with new one 