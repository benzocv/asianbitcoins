class Functionality1 {
  void getHeight() {}
}
